# jquery-flip-clock
A jQuery plugin that be used to countdown the time in 3D style
